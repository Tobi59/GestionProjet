package worldline.ssm.rd.ux.wltwitter.pojo;

public class TwitterAuthenticated {
	public String token_type;
	public String access_token;
}
