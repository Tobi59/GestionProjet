package worldline.ssm.rd.ux.wltwitter;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class WLTwitterLoginActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(this,"did you click the button",Toast.LENGTH_LONG).show();
    }
}
